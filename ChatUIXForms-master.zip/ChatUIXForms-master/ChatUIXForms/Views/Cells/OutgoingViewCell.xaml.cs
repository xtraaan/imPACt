﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace ChatUIXForms.Views.Cells
{
    public partial class OutgoingViewCell : ViewCell
    {
        public OutgoingViewCell()
        {
            InitializeComponent();
        }
    }
}
