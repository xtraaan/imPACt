﻿using System;
namespace ChatUIXForms.Models
{
    public class Message
    {
        public string Text { get; set; }
        public string User { get; set; }
    }
}
