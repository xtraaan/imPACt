# ChatUIXForms

Blog Post Series:

- http://www.xamboy.com/2018/06/14/exploring-a-chat-ui-in-xamarin-forms-part-1/
- http://www.xamboy.com/2018/07/09/exploring-a-chat-ui-in-xamarin-forms-part-2/
- http://www.xamboy.com/2018/08/30/exploring-a-chat-ui-in-xamarin-forms-part-3/
